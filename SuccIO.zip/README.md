# Succ.io
Fan remake of Sily.co 

I'm refreshing my basic JavaScript and relearning Node.JS and Socket.IO through making this. 
